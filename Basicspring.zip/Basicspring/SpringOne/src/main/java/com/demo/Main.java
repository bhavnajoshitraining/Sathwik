package com.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.Employee;

public class Main {

	public static void main(String[] args) {
		ApplicationContext con = new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee e = con.getBean("e",Employee.class);
		System.out.println(e.getSalary());
		System.out.println(e);
	}

}
