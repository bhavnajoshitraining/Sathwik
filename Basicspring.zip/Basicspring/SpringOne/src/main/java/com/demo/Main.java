package com.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.demo.model.Employee;

public class Main {

	public static void main(String[] args) {
		Resource r = new ClassPathResource("applicationContext.xml");
		BeanFactory f=new XmlBeanFactory(r);
		
		Employee e =(Employee) f.getBean("e");
		System.out.println(e.getSalary());
		System.out.println(e);
//		ApplicationContext con = new ClassPathXmlApplicationContext("applicationContext.xml");
//		Employee e = con.getBean("e",Employee.class);
//		System.out.println(e.getSalary());
//		System.out.println(e);
	}

}
